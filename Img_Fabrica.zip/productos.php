<?php 
session_start();
$_SESSION['USUARIO'] = "";
$_SESSION['alerta'] = "";
include("template/cabecera.php"); ?>

<div class="yellow_bg">
    <div class="container center">
        <div class="row">
            <div class="">
                <div class="title">

                    <h1>Nuestros Productos</h1>


                </div>


            </div>


        </div>

    </div>
</br>
</br>
</div>






<?php
include("administrador/config/db.php");
$sentenciaSQL = $conexion->prepare("SELECT * FROM productos");
$sentenciaSQL->execute();
$listaProductos = $sentenciaSQL->fetchAll(PDO::FETCH_ASSOC);
?>

<?php foreach ($listaProductos as $producto)   {  ?>
    <?php if($producto['imagen'] != "imagen.jpg") :?>
    <div class="col-md-3">
        <div class="card">
          
            <img class="card-img-top" src="./img/<?php  echo $producto['imagen']; ?>" alt="" style="height:300px">
           
            <div class="card-body">
                <h4 style="color: black;" class="card-title"><?php echo $producto['nombre']; ?></h4>

            </div>


        </div>
</br>
</br>
    </div>
    <?php endif?>
<?php } ?>


<fooetr>


    <div class="d-flex justify-content-center m-5">
        <div class="img-box">
            <figure><img src="imagenes/fabrica.jpg" alt="" height="500px" /></figure>
        </div>
    </div>

    <div class="row">
        <div class="col-md-3">
            <div class="footer_logo">
                <a href="index.html"><img src="" alt="" /></a>
            </div>
            </br>
            

        </div>

        <div class="d-flex justify-content-center m-5">
            <ul class="lik">
                <li class="nav-item">
                    <a class="btn btn-primary btn-lg" href="<?php echo $url; ?>/contacto.php">Contactos</a>
                </li>

               
            </ul>
        </div>

    </div>
</fooetr>






    <?php include("template/pie.php"); ?>