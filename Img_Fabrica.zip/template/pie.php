
<div class="overlay"></div>

<fooetr style="width: 100% !important;">
     <div class="copyright">
          <div class="container">
               <p>© <?php echo date('Y');  ?> All Rightse Reserved. Design by<a> TecnoEAM</a></p>
          </div>
     </div>
</fooetr>


     </div>
     </div>
</body>

</html>