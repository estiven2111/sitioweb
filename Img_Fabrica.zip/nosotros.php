<?php
session_start();
session_destroy();
$_SESSION['USUARIO'] = "";
$_SESSION['alerta'] = "";
include("template/cabecera.php"); ?>
<div class="jumbotron">
    <h1 class="display-3">La fabrica del frito</h1>
    <p class="lead"></p>
    <hr class="my-2">
</br>
</div>


<div class="container">
    <div class="row">
        <div class="col-xl-6 col-sm-6 col-md-6" style="text-align:justify;">
            <p>Somos una empresa con una gran trayectoria, dedicados a distribuir productos como Empanadas, Pasteles, Palitos de queso y mas;
                con una gran variedad de sabores que nos identifican con sabores unicos e inigualables, distrubuyendo en gran parte de la ciudad de Medellín
                productos fritos y pre fritos, dando opciones a nuestros clientes de adquirir nuestros productos.
                Si deseas disfrutar de nuestros sabores puedes encontrarnos en el barrio Boston, cerca al tran via.
                Si deseas comprar al por mayor comunicate con nosotros, esteremos encantados de llevarte nuestros productos a la puerte de tu negocio.
            </p>
        </div>
        <div style="height: 300px; width: 40%;">
    <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="imagenes/pedidos.jpg" class="d-block" alt="..." style="height: 300px; width: 100%;">
            </div>
            <div class="carousel-item">
                <img src="imagenes/fabrica.jpg" class="d-block" alt="..." style="height: 300px; width: 100%;">
            </div>
            <div class="carousel-item">
                <img src="imagenes/carta.jpg" class="d-block" alt="..." style="height: 300px; width: 100%;">
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
</div>

        </div>
        </br></br> </br></br>
    </div>
    
</div>

<div class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class=" col-md-6">
                <h2>Escríbenos<strong class="white"> </strong></h2>
            </div>

    
            <div class="col-md-5">

                <form class="main_form">
                    <div class="row">

                        <div class="mb-3">
                            <input class="form-control" placeholder="Nombre" type="text" name="Nombre">
                        </div>
                        <div class="mb-3">
                            <input class="form-control" placeholder="Email" type="text" name="Email">
                        </div>
                        <div class="mb-3">
                            <input class="form-control" placeholder="Telefono" type="text" name="Telefono">
                        </div>

                        


                        <div class="mb-3">
                            <textarea class="textarea" placeholder="Mensaje" type="text" name="Mensaje" rows="6"></textarea>
                        </div>

                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                            <button class="btn btn-primary btn-lg">Enviar</button>
                        </div>
                    </div>
                </form>

                </br></br></br>
            </div>

            <?php include("template/pie.php"); ?>